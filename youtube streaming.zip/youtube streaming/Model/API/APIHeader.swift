//
//  APIHeader.swift
//  Project
//
//  Created by Ricky_DO on 3/19/18.
//  Copyright © 2018 Pathmazing. All rights reserved.
//

import Foundation
import Alamofire

struct APIHeader {
    
    static func getAuthorizationUser() -> [String: String] {
        return [:]
    }
    
    static func getAuthorizationApp() -> [String: String] {
        return [:]
    }
    
    static func getAuthorizationVideo() -> [String: String] {
        return [:]
    }
    
    static func getAuthorizationImage() -> [String: String] {
        return [:]
    }
    
}
