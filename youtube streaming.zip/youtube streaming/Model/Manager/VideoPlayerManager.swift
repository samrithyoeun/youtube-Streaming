//
//  PlayerManger.swift
//  youtube streaming
//
//  Created by Samrith Yoeun on 7/10/18.
//  Copyright © 2018 PM Academy 3. All rights reserved.
//

import Foundation
import AVFoundation
import AVKit

class PlayerMangaer  {
    static var share: VideoPlayerViewController?
}
